import * as React from "react";

const Input = React.forwardRef<HTMLInputElement, React.ComponentProps<"input">>(
  ({ className = "", type = "text", ...props }, ref) => {
    return (
      <input
        ref={ref}
        type={type}
        className={
          `flex h-10 w-full rounded-lg border-2 border-input bg-background px-3 py-2 text-sm text-foreground ` +
          `caret-foreground placeholder:text-muted-foreground shadow-sm outline-none ` +
          `transition-[border-color,box-shadow] duration-150 ` +
          `focus:border-ring focus:ring-2 focus:ring-ring/20 ` +
          `disabled:cursor-not-allowed disabled:opacity-50 ${className}`
        }
        {...props}
      />
    );
  },
);

Input.displayName = "Input";

export { Input };
